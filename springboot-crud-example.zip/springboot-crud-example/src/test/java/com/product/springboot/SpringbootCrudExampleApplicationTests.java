package com.product.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
